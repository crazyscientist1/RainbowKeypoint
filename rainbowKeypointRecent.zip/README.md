# Rainbow curve prediction
Predicting the arc of a rainbow using keypoints.
